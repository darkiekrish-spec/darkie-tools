# Darkie Security Suite v3 — Ultimate Cyber Toolkit

Multi-module cybersecurity platform for network monitoring, vulnerability scanning,
OSINT reconnaissance, penetration testing, SIEM, stress testing, and more.

## Quick Start

### Linux
```bash
# Terminal
python3 tool.py

# Desktop GUI (tkinter)
python3 gui/app.py

# Web GUI (for VPS/remote)
python3 gui/web_app.py --host 0.0.0.0 --port 5000
# Open http://localhost:5000 in your browser
```

### Windows
```
# Terminal (CMD)
launchers\windows.bat

# Terminal (PowerShell)
launchers\windows.ps1

# GUI
launchers\windows_gui.bat

# Web GUI
launchers\web_launcher.bat
```

### macOS
```bash
# Terminal
launchers/macos.sh

# GUI (tkinter)
launchers/macos_gui.sh
```

## Installation

### Debian/Ubuntu (.deb)
```bash
sudo dpkg -i dist/darkie-suite_3.0.0_all.deb
sudo apt-get install -f
darkie-suite      # Terminal
darkie-suite-gui  # GUI
darkie-suite-web  # Web GUI (VPS)
```

### Windows (.exe)
```cmd
packaging\build_exe.bat
# Output in dist/DarkieSuite_CLI.exe and dist/DarkieSuite_GUI.exe
```

### Docker (VPS)
```bash
cd packaging/docker
docker-compose up -d
# Open http://YOUR_VPS_IP:5000
```

## Modules
- Network Threat Monitoring
- Endpoint Security
- Vulnerability Management
- Data & Access Protection
- Penetration Testing
- SIEM & Log Analysis
- Stress Testing (Minecraft)
- OSINT Reconnaissance
- Telephone Tools
- Network Utilities
- Hash & Crypto Tools
- System Security Audit
- Advanced Network
- Advanced OSINT (Censys Search, Recon Engine)
- WiFi & Wireless
- Report Generator

## Requirements
- Python 3.8+
- Dependencies: `pip install -r requirements.txt`
- tkinter for GUI: `apt install python3-tk` (Linux) / `brew install python-tk` (macOS)
- Windows: Python from python.org includes tkinter

## License
Educational use only. Test only systems you own or have permission to test.
